
import os
import django

# Set up the Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'tienda.settings')
django.setup()

# Now we can import the Product model
from productos.models import Producto

# Sample data for products
sample_products = [
    {"nombre": "iPhone 12 Pro", "precio": 1000, "cantidad_inventario": 10, "descripcion": "lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt"},
    {"nombre": "Xiaomi 11T Pro", "precio": 400, "cantidad_inventario": 25, "descripcion": "lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incidid"},
    {"nombre": "Samsung 20S", "precio": 500, "cantidad_inventario": 20, "descripcion": "lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incidid"},
    # Añade más productos según sea necesario
]

# Create and save the sample products
for product_data in sample_products:
    try:
        # Check if the product already exists to avoid duplicates
        producto, created = Producto.objects.get_or_create(**product_data)
        if created:
            print(f'Producto {producto.nombre} creado con éxito.')
        else:
            print(f'Producto {producto.nombre} ya existe.')
    except Exception as e:
        print(f'Error al crear el producto {product_data["nombre"]}: {e}')

