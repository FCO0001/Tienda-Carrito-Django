from django.db import models

class Producto(models.Model):
    nombre = models.CharField(max_length=255)
    precio = models.DecimalField(max_digits=10, decimal_places=2)
    cantidad_inventario = models.PositiveIntegerField()
    descripcion = models.TextField(null=True)

    def __str__(self):
        return self.nombre

# Nuevo modelo para representar un ítem dentro del carrito de compras
class CarritoItems(models.Model):
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE)
    cantidad = models.PositiveIntegerField(default=1)

    def __str__(self):
        return f"{self.cantidad} de {self.producto.nombre}"

    @property
    def subtotal(self):
        return self.producto.precio * self.cantidad

# Nuevo modelo para representar el carrito de compras
class Carrito(models.Model):
    items = models.ManyToManyField(CarritoItems)
    session_key = models.CharField(max_length=40, unique=True, null=True)
    
    @property
    def total(self):
        return sum(item.subtotal for item in self.items.all())


    