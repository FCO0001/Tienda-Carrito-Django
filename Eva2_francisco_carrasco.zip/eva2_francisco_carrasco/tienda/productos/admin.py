from django.contrib import admin
from .models import Producto

@admin.register(Producto)
class ProductoAdmin(admin.ModelAdmin):
    list_display = ['nombre', 'precio', 'cantidad_inventario', 'descripcion']
    list_editable = ['precio', 'cantidad_inventario', 'descripcion']
    search_fields = ['nombre', 'precio', 'cantidad_inventario', 'descripcion']
   

    