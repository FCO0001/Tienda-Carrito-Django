

    
from django.urls import path
from .views import listar_productos, comprar_producto, simulador_tienda, add_to_cart, cart_view, remove_from_cart

urlpatterns = [
    path('productos/', listar_productos, name='listar_productos'),
    path('comprar/<int:producto_id>/', comprar_producto, name='comprar_producto'),
    path('tienda/', simulador_tienda, name='simulador_tienda'),
    path('add-to-cart/<int:producto_id>/', add_to_cart, name='add_to_cart'),
    path('cart/', cart_view, name='cart_view'),
    path('remove-from-cart/<int:cart_item_id>/', remove_from_cart, name='remove_from_cart'),
    path('', simulador_tienda, name='simulador_tienda'),
]
