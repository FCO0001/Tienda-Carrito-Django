
from django.shortcuts import render, redirect, get_object_or_404
from .models import Producto, Carrito, CarritoItems

def listar_productos(request):
    productos = Producto.objects.all()
    return render(request, 'productos/listar.html', {'productos': productos})

def comprar_producto(request, producto_id):
    producto = Producto.objects.get(id=producto_id)
    if producto.cantidad_inventario > 0:
        producto.cantidad_inventario += 1
        producto.save()
    return redirect('listar_productos')

def simulador_tienda(request):
    productos = Producto.objects.all()
    return render(request, 'productos/simulador_tienda.html', {'productos': productos})


def add_to_cart(request, producto_id):
    # Ensure there is a session key
    if not request.session.session_key:
        request.session.save()
    session_key = request.session.session_key

    cart, _ = Carrito.objects.get_or_create(session_key=session_key)
    producto = get_object_or_404(Producto, id=producto_id)
    cart_item, created = CarritoItems.objects.get_or_create(producto=producto, defaults={'cantidad': 1})
    
    if not created:
        cart_item.cantidad += 1
    cart_item.save()
    
    # Add the cart_item to the cart's items
    cart.items.add(cart_item)
    cart.save()

    return redirect('cart_view')


def cart_view(request):
    if not request.session.session_key:
        request.session.save()
    session_key = request.session.session_key

    cart, _ = Carrito.objects.get_or_create(session_key=session_key)
    return render(request, 'productos/cart.html', {'cart': cart})

def remove_from_cart(request, cart_item_id):
    cart_item = get_object_or_404(CarritoItems, id=cart_item_id)
    cart = Carrito.objects.get(id=request.session.session_key)
    cart.items.remove(cart_item)
    cart_item.delete()
    return redirect('cart_view')
 